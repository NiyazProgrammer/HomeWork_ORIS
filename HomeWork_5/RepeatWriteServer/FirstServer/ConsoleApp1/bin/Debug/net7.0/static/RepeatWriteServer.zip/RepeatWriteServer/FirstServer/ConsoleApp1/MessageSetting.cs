namespace ConsoleApp1;

public class MessageSetting
{
    public string Email { get; set; }
    public string Password { get; set; }
}