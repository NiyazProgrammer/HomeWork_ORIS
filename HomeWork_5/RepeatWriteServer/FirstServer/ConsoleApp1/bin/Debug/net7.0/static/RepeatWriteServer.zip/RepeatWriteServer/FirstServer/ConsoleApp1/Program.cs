﻿using System.Net;
using System.Text;
using System.Text.Json;
using ConsoleApp1.Configuration;

namespace ConsoleApp1;

class Program
{
    private static async Task Main(string[] args)
    {
        try
        {
            var server = new HttpServer();
            
            await server.StartAsync();

            // Console.WriteLine("Нажми на любую клавишу");
            // Console.ReadKey();
            // Console.WriteLine();
            // server.StopServer();
            
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex}");
        }
    }
}

